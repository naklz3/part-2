﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pong
{
    public partial class Form1 : Form
    {
        //игровые обьекты
        int leftPaddleY = 200;//левая ракетка
        int rightPaddleY = 200;//правая ракетка
        int ballX = 400;//мяч х
        int ballY = 300;//мяч у
        int ballSpeedX = 5;//скорость мяча х
        int ballSpeedY = 5;//скорость мяча у
        int leftscore = 0;//счет игрока слева
        int rightscore = 0;//счет игрока справа
        bool gameRunning = true;//игра активна
        Timer timer; //таймер анимацаии
        Random random = new Random();

        public Form1()
        {
            InitializeComponent();
            //настройка формы 
            this.Text = "Pong game";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.Paint += Form1_Paint;
            this.KeyDown += Form1_KeyDown;

            timer = new Timer();
            timer.Interval = 16;
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (gameRunning)
            {
                // сохраняем старую позицию для отката при столкновении
                int oldBallX = ballX;
                int oldBallY = ballY;

                ballX += ballSpeedX;
                ballY += ballSpeedY;

                // отскок от верха и низа
                if (ballY - 8 <= 0 || ballY + 8 >= this.ClientSize.Height)
                {
                    ballSpeedY = -ballSpeedY;
                    // корректируем позицию
                    if (ballY - 8 <= 0) ballY = 8;
                    if (ballY + 8 >= this.ClientSize.Height) ballY = this.ClientSize.Height - 8;
                }

                // отскок от левой ракетки
                if (ballX - 8 <= 45 && ballX + 8 >= 30 &&
                    ballY + 8 >= leftPaddleY && ballY - 8 <= leftPaddleY + 100)
                {
                    // откатываем позицию мяча
                    ballX = oldBallX;
                    ballY = oldBallY;

                    ballSpeedX = -ballSpeedX;

                    // меняем угол в зависимости от места попадания
                    int hitPos = ballY - leftPaddleY;
                    ballSpeedY = (hitPos - 50) / 4;

                    // ограничиваем скорость по Y
                    if (Math.Abs(ballSpeedY) < 3) ballSpeedY = (ballSpeedY >= 0) ? 3 : -3;
                    if (ballSpeedY > 8) ballSpeedY = 8;
                    if (ballSpeedY < -8) ballSpeedY = -8;

                    // небольшое увеличение скорости
                    if (Math.Abs(ballSpeedX) < 8) ballSpeedX = (ballSpeedX > 0) ? 6 : -6;
                }

                // отскок от правой ракетки
                if (ballX + 8 >= this.ClientSize.Width - 45 && ballX - 8 <= this.ClientSize.Width - 30 &&
                    ballY + 8 >= rightPaddleY && ballY - 8 <= rightPaddleY + 100)
                {
                    // откатываем позицию мяча
                    ballX = oldBallX;
                    ballY = oldBallY;

                    ballSpeedX = -ballSpeedX;

                    // меняем угол в зависимости от места попадания
                    int hitPos = ballY - rightPaddleY;
                    ballSpeedY = (hitPos - 50) / 4;

                    // ограничиваем скорость по Y
                    if (Math.Abs(ballSpeedY) < 3) ballSpeedY = (ballSpeedY >= 0) ? 3 : -3;
                    if (ballSpeedY > 8) ballSpeedY = 8;
                    if (ballSpeedY < -8) ballSpeedY = -8;

                    // небольшое увеличение скорости
                    if (Math.Abs(ballSpeedX) < 8) ballSpeedX = (ballSpeedX > 0) ? 6 : -6;
                }

                // гол слева
                if (ballX - 8 <= 0)
                {
                    rightscore++;
                    ResetBall();
                }
                // гол справа
                else if (ballX + 8 >= this.ClientSize.Width)
                {
                    leftscore++;
                    ResetBall();
                }

                // проверка победы
                if (leftscore >= 5 || rightscore >= 5)
                {
                    gameRunning = false;
                    timer.Stop();
                }

                // AI для правой ракетки
                int targetY = ballY - 50;
                int delta = targetY - rightPaddleY;
                rightPaddleY += Math.Sign(delta) * Math.Min(Math.Abs(delta) / 3, 5);

                // ограничиваем движение ракеток
                leftPaddleY = Math.Max(0, Math.Min(this.ClientSize.Height - 100, leftPaddleY));
                rightPaddleY = Math.Max(0, Math.Min(this.ClientSize.Height - 100, rightPaddleY));
            }
            this.Invalidate();
        }

        void ResetBall()
        {
            ballX = this.ClientSize.Width / 2;
            ballY = this.ClientSize.Height / 2;
            ballSpeedX = (random.Next(2) == 0) ? 5 : -5;
            ballSpeedY = (random.Next(2) == 0) ? 5 : -5;

            // пауза перед следующим розыгрышем
            gameRunning = false;
            Timer delayTimer = new Timer();
            delayTimer.Interval = 800;
            delayTimer.Tick += (s, e) =>
            {
                gameRunning = true;
                delayTimer.Stop();
                delayTimer.Dispose();
            };
            delayTimer.Start();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillRectangle(Brushes.Black, 0, 0, this.Width, this.Height);

            // центральная линия
            Pen whitePen = new Pen(Color.White, 2);
            for (int y = 0; y < this.Height; y += 20)
            {
                g.DrawLine(whitePen, this.Width / 2, y, this.Width / 2, y + 10);
            }

            // ракетки
            g.FillRectangle(Brushes.White, 30, leftPaddleY, 15, 100);
            g.FillRectangle(Brushes.White, this.Width - 45, rightPaddleY, 15, 100);

            // мяч
            g.FillEllipse(Brushes.White, ballX - 8, ballY - 8, 16, 16);

            // счет
            Font font = new Font("Arial", 30, FontStyle.Bold);
            g.DrawString(leftscore.ToString(), font, Brushes.White, this.Width / 4 - 20, 20);
            g.DrawString(rightscore.ToString(), font, Brushes.White, 3 * this.Width / 4 - 20, 20);

            // сообщение о победе
            if (!gameRunning && (leftscore >= 5 || rightscore >= 5))
            {
                string winner = (leftscore >= 5) ? "ЛЕВЫЙ ПОБЕДИЛ!" : "ПРАВЫЙ ПОБЕДИЛ!";
                Font winFont = new Font("Arial", 24, FontStyle.Bold);
                SizeF textSize = g.MeasureString(winner, winFont);
                g.DrawString(winner, winFont, Brushes.Yellow, this.Width / 2 - textSize.Width / 2, this.Height / 2 - 50);

                Font restartFont = new Font("Arial", 16);
                string restartText = "Нажмите R для перезапуска";
                SizeF restartSize = g.MeasureString(restartText, restartFont);
                g.DrawString(restartText, restartFont, Brushes.White, this.Width / 2 - restartSize.Width / 2, this.Height / 2 + 20);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (gameRunning)
            {
                if (e.KeyCode == Keys.W)
                {
                    leftPaddleY -= 20;
                }
                if (e.KeyCode == Keys.S)
                {
                    leftPaddleY += 20;
                }
                leftPaddleY = Math.Max(0, Math.Min(this.ClientSize.Height - 100, leftPaddleY));
            }

            if (e.KeyCode == Keys.R)
            {
                leftscore = 0;
                rightscore = 0;
                gameRunning = true;
                ResetBall();
                timer.Start();
                this.Invalidate();
            }
        }
    }
}